const { createlicense } = require('./createlicense.js');

module.exports ={
    createlicense,

}
/* Code Licensed By Space Development
* Copyright © Space Development 2022-2023
* Removing Of This Credit And License Is Resulted As Code Pirating
* Please Give Us A Little Credit to as a hard work
* Dont be a skidder :)
*/