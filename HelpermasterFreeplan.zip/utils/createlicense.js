function createlicense(length) {
    var result = "";
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    for (var i = 0; i < length; i++) {
      result += characters[Math.floor(Math.random() * characters.length)];
  
    }
    result = result.match(/.{1,4}/g).join("-");
    return result;
  }
  
  module.exports = {
    createlicense
  }