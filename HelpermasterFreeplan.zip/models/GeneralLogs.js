const mongoose = require("mongoose");
const schm = new mongoose.Schema({
  Guild: String,
  MemberRole: Boolean,
  MemberNick: Boolean,
  ChannelTopic: Boolean,
  MemberBoost: Boolean,
  RoleStatus: Boolean,
  ChannelStatus: Boolean,
  EmojiStatus: Boolean,
  MemberBan: Boolean

});

module.exports = mongoose.model("generallogs", schm);

/* Code Licensed By Space Development
* Copyright © Space Development 2022-2023
* Removing Of This Credit And License Is Resulted As Code Pirating
* Please Give Us A Little Credit to as a hard work
* Dont be a skidder :)
*/