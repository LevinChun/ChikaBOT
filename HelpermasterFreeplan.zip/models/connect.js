const mongoose = require("mongoose");

async function connect() {
  mongoose.connect("mongodb+srv://HelperMaster:udayana10@helpermastercluster1.il75mh5.mongodb.net/?retryWrites=true&w=majority" ,
    {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useCreateIndex: true,
      useFindAndModify: false,
    }
  );

  mongoose.connection.once("open", () => {
    console.log("Connected to Database");
  });
  return;
}

module.exports = connect;
/* Code Licensed By Space Development
* Copyright © Space Development 2022-2023
* Removing Of This Credit And License Is Resulted As Code Pirating
* Please Give Us A Little Credit to as a hard work
* Dont be a skidder :)
*/