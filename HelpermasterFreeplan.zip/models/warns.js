const { model, Schema } = require('mongoose');

const sch = new Schema({
  Guild: String,
  User : String,
  Array: Array,
})

module.exports = model('warns', sch)
/* Code Licensed By Space Development
* Copyright © Space Development 2022-2023
* Removing Of This Credit And License Is Resulted As Code Pirating
* Please Give Us A Little Credit to as a hard work
* Dont be a skidder :)
*/