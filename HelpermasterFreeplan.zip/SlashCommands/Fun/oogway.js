const Discord = require(`discord.js`)
const fetch = require("node-fetch");

module.exports = {
    name: "oogway",
    category: "fun",
    description: "Make Master Oogway Say Something...",
    type: 'CHAT_INPUT',
    options: [
        {
            name: 'text',
            description: 'The Text for master oogway to say',
            required: true,
            type: `STRING`
        }],
    run: async (client, interaction, args) => {
      let text = interaction.options.getString('text');
      let msg = await interaction.followUp(`Combining your text with the image...`);

      

      
      const embed = new Discord.MessageEmbed()
      .setAuthor("Master oogway")
      .setDescription(`Thanks for using helpermaster`)
      .setImage(`https://api.popcat.xyz/oogway?text=${text}`)
      .setFooter(`aa`)
      .setColor('#f7c555')
      
      setTimeout(() => {
        msg.edit({ content: ` `, embeds: [embed] });
      }, 500);
    }
}
