const Discord = require(`discord.js`)
const fetch = require("node-fetch");

module.exports = {
    name: "quote",
    category: "fun",
    description: "Random Quotes :)",
    type: 'CHAT_INPUT',
    run: async (client, interaction, args) => {
      let msg = await interaction.followUp(`Searching for random quotes online...`);

      
      let data = await fetch("https://api.popcat.xyz/quote").then(x => x.json())
      const embed = new Discord.MessageEmbed()
      .setAuthor(data.quote, client.user.displayAvatarURL(), `https://dsc.gg/spacedevdc`)
      
      .setFooter(`${data.upvotes} 👍`)
      .setColor('#f7c555')
      
      setTimeout(() => {
        msg.edit({ content: ` `, embeds: [embed] });
      }, 500);
    }
}
