const UrlsConfig = require("./../../models/Urlconfig.js");
const { Client, MessageEmbed, Message } = require("discord.js");
const fetch = require("node-fetch");
const validUrl = require("valid-url");

module.exports = {
    name: 'monitor-add',
    category: "Uptimer",
    description: "⛳Add Your Project to my database and keep them 24/7",
    type: 'CHAT_INPUT',
    options: [
        {
                name: "urls",
                type: 3,
                description: "Url You Want To Add To My Database",
required: true
        }
],
  run: async (client, interaction, args) => {
    let msg = await interaction.followUp(`<a:loading:993445822798778438> Please Wait While im Adding Your URl To My Database`);
    var url = args.join(" ");

    if (!url) return interaction.followUp({ content: "Please provide a project url" });
    if (!validUrl.isUri(url)) {
      return interaction.followUp({ content: "Please provide a vaild url Using Its http protocol Example: http:// or https://" });
    }
        
    var interactionA = await interaction.followUp({ content: `<@${interaction.member.user.id}>`, embeds: [new MessageEmbed().setColor("WHITE").setDescription(" <a:loading:957145065900363829> Please wait...").setFooter(interaction.member.user.tag).setThumbnail(interaction.member.user.displayAvatarURL())] });

    var checkIfExsists = await UrlsConfig.findOne({
      projectURL: url,
    });

    if (checkIfExsists === null) {
      
      await UrlsConfig.create({
        authorID: interaction.member.user.id,
        projectURL: url,
        pinged: 0,
      }).then(async () => {
        
    
        try {
          
          await fetch(url);
        } catch (e) {
          
          await UrlsConfig.findOneAndUpdate(
            { projectURL: url },
            { error: true, errorText: e.message },
            { new: true }
          );
          interaction.followUp({ content: "r" });
        }
        
        await interactionA.edit({ embeds: [new MessageEmbed().setTitle(" <a:yes:962966293764505620> Added Your Link To My Database").setColor("RED").setDescription("<a:yes:962966293764505620> I Added Your Project To My Database!\n It Should be 87% uptime by the time").setFooter("Powered by Space Development🚀")] });
        
      });
    } else {      
      
      await interactionA.edit({ embeds: [new MessageEmbed().setTitle("Error | Already Registered").setDescription("The Project you're Trying To Register Is Already In The Database").setColor("RED").setFooter("Powered By Space Development🚀").setThumbnail(client.user.displayAvatarURL()).setTimestamp()] });
    }
  },
};
