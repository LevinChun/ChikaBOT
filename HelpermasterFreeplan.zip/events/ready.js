const { red, green, blue, magenta, cyan, white, gray, black } = require("chalk");
const client = require("../index");
const config = require("../config.json")
const exec = require('child_process').exec;
const Discord = require("discord.js")
const fs = require("fs")
const chalk = require("chalk")


client.on("ready", () => {
    let idkwhatisthis = false
    console.log(cyan.bold(`[🚩Info] Powered By Space Development🚀`));
    console.log(cyan.bold(`[🚩Info] Successfully Loaded All Events!`));
    console.log(green(`[🚩Info] → ` + magenta(`${client.user.tag}`) +  ` is up & ready!| Thanks for your purchase At Space Development!`));
    console.log(green(`[🚩Info] → https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`))
    if(config.settings.updateFromGithub){
        setInterval(async () => {
            await exec(`git pull origin main`, async (error, stdout) => {
                let response = (error || stdout);
                if (!error) {
                    if (!response.includes("Already up to date.")){
                        console.log(`${chalk.red('[ GitHub ]')} Update found on github. downloading now!`);
                        await client.channels.cache.get("1036119246025003129").send({content: "**Update Detected On Github <a:yes:964445140548734978>**", embeds:[
                            new Discord.MessageEmbed()
                            .setTitle(`**[AutoUpdate]** New update on GitHub. Pulling.`)
                            .setColor(`BLUE`)
                            .setFooter("Autoupdate System By Artiom | Powered By Space Development🚀")
                            .setDescription(`Logs:\n\`\`\`\n${response}\`\`\``)
                        ]})
                        console.log(`${chalk.red('[ GitHub ]')} the new version had been installed. Restarting now . . .`)
                        process.exit(5)
                    }else {
                        if(!idkwhatisthis) {console.log(`${chalk.green('[ GitHub ]')} Bot is up to date\n`); idkwhatisthis = true}
                    }
                }else{
                    console.log(`${chalk.red('[ GitHub ]')} Error: ${error}\n`)
                }
            })
        }, 30000)
    }
    
    const activities = [
        { name: `dashboard.helpermaster.tk`, type: 2 } // LISTENING
    ];
    const status = [
        'online',
        'dnd',
        'idle'
    ];
    let i = 0;
    setInterval(() => {
        if(i >= activities.length) i = 0
        client.user.setActivity(activities[i])
        i++;
    }, 5000);
  
    let s = 0;
    setInterval(() => {
        if(s >= activities.length) s = 0
        client.user.setStatus("idle")
        s++;
    }, 30000);
});