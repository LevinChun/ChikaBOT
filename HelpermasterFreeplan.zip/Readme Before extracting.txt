Hi There!🌷Thanks for your purchase at **Space Development!**

Here's How You Can Start The bot

1. Enter Your License key on config.json or else it wont work💀
2. Type npm i To Install all the dependencies that needed
3. Type node .
4. Enjoy your bot

btw this handler is custom so u cant put the commands to other bots hehe

Dont ever try to leak this code
also if your license isnt valid anymore you can DM Udayana#5236 And Send your payment proof!

-----------------Big Thanks By Udayana-----------------------------